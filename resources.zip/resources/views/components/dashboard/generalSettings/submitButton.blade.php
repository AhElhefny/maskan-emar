<div class="row">
    <div class="col-12">
        <button type="submit" class="btn btn-primary mr-1 mb-1" onclick="fillTextarea()" id="{{$id??null}}">{{__('dashboard.submit')}}</button>
    </div>
</div>
